package com.nt;

import org.springframework.stereotype.Service;

//@Component
@Service
public class LoginService {
	
	public boolean validateUser(String user, String password){
		return user.equalsIgnoreCase("NIT")&& password.equalsIgnoreCase("rani");
	}

}
