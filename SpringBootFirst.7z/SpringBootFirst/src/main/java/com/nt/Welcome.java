package com.nt;

import org.springframework.context.annotation.Configuration;

@Configuration
public class Welcome {
	
	public void sum() {
		System.out.println("hi sum method");
	}

}
