package com.nt;

import org.springframework.stereotype.Service;

//@Component
@Service
public class WelcomeService {
	//org.springframework.web
	public String retrieveWelcomeMessage() {
	//	System.out.println("HI welcome message");
		int p=1000, r=2, t=2;
		double si=(p*t*r)/100;
		return "\n Good Morning SpringBoot my simple interrest is :: "+si;
	}

}
