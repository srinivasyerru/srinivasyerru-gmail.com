package com.nt.web.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.nt.web.model.Todo;

@Service
public class TodoService {
	
	private static List<Todo> todos=new ArrayList<Todo>();
	
	private static int todoCount = 3;
	
	
	
	static{
		todos.add(new Todo(1, "NIT","springMVC ", new Date(), false));

		todos.add(new Todo(2, "NIT","springBoot", new Date(), false));

		todos.add(new Todo(3, "NIT","Java ", new Date(), false));
	}
	
	public List<Todo> retrieveTodo(String user){
		
		
		List<Todo> filterTodos =new ArrayList<Todo>();
		
		for(Todo todo:todos) {
			if(todo.getUser().equals(user)) {
				filterTodos.add(todo);
				System.out.println("todos:: "+todo);
			}
		}
		
		return filterTodos;
		
	}
	
	
	public void addTodo(String name, String desc,Date targateDate,boolean isDone) {
		
		todos.add(new Todo(++todoCount,name, desc, targateDate, isDone));
	}

}
