package com.nt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

//@RestController
//@RestController
@Controller
@SessionAttributes("name")
public class WelcomeController {
	
	//RequstingMapping
	//RestController
	
	//WelcomeService ws=new WelcomeService();
	//Auto wiring
	@Autowired
	private WelcomeService welcomeService;
	//WelcomeService  welcomeService=new WelcomeService();
	@Autowired
	LoginService  loginService;
	
	//@RequestMapping("/dis")
	@GetMapping("/dis")
	@ResponseBody
	public String display() {
		//welcomeService.retrieveWelcomeMessage();
		return "hi how are you , welcome to spring boot\n"+welcomeService.retrieveWelcomeMessage();
	}
	@GetMapping("/disP")
	@ResponseBody
	public String displayParam(@RequestParam String name) {
		//welcomeService.retrieveWelcomeMessage();
		System.out.println( "name "+name);
		return "hi how are you , welcome to spring boot\n"+welcomeService.retrieveWelcomeMessage()+"name :: "+name;
	}
	
	/*@GetMapping("/loginP")
	public String loginPage(@RequestParam String name, ModelMap model) {
		
		//model.put("name", name);
		model.put("name", name);
		System.out.println("name :: "+name);
		return "login";
	}*/
	
	
	  @RequestMapping(value="/loginPage", method=RequestMethod.GET) 
	  public String	  loginMessage(ModelMap model) {
		  System.out.println("login uisng get method");
		  return "login"; 
		  }
	 
	@RequestMapping(value="/loginPage", method = RequestMethod.POST)
	public String showMessage(ModelMap model, @RequestParam String name, @RequestParam String password) {
		System.out.println("login using post method");
		boolean isValidUser=loginService.validateUser(name, password);
		
		if(!isValidUser) {
			model.put("errorMessage","Invalid Credentials..");
			return "login";
			
		}else {
			model.put("name",name);
			model.put("password",password);
			return "welcome";
				
		}
		
		
		//return "welcome";
	}
	@GetMapping("/per")
	public String perform() {
		return "my perfomrance is good";
	}
	
	/*public String welcome() {
		System.out.println("welcome controller");
		return welcomeService.retrieveWelcomeMessage();
		
	}*/
	

}
