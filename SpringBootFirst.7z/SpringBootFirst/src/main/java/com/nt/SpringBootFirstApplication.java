package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//@ComponentScan({"com.nt.web","com.nt","com.nt.controller","com.nt.web.model","com.nt.web.service"})
public class SpringBootFirstApplication {

	public static void main(String[] args) {
	SpringApplication.run(SpringBootFirstApplication.class, args);
		
		System.out.println("Welcoem to java SpringBoot");
		
		
		
		
		
		
		
		
		
		
		
		/*
		 * Welcome s1 =new Welcome(); s1.sum();
		 * 
		 * Welcome w=apc.getBean(Welcome.class); w.sum();
		 * 
		 * 
		 * String[] beanNames=apc.getBeanDefinitionNames();
		 * Arrays.parallelSort(beanNames);
		 * 
		 * for(String beanName : beanNames) { System.out.println(beanName); }
		 * 
		 * //Welcome w=new Welcome(); //w.sum();
		 */		
	}

}
