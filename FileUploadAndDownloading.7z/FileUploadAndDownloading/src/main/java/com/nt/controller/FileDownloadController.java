package com.nt.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Path;

import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/download")
public class FileDownloadController {

	
	
	
	private static final String EXTERNAL_FILE_PATH="C:/Srinivas Softwares/";
	
	@RequestMapping("/dow")
	@ResponseBody
	public Set<String> listFilesUsingDirectoryStream() throws IOException {
		String dir="C:/Srinivas Softwares/";
		Set<String> fileList=new HashSet<>();
		try(DirectoryStream<java.nio.file.Path> stream = Files.newDirectoryStream(Paths.get(dir))){
			for(java.nio.file.Path path: stream) {
				if(!Files.isDirectory(path)) {
					fileList.add(path.getFileName()
					.toString());
				}
			}
			
		}
		
		
		
		return fileList;
	}
	
	@RequestMapping("file/{fileName:.+}")
	public void downloadPDFResource(HttpServletRequest request, HttpServletResponse response,@PathVariable("fileName") String fileName) throws IOException {
		
		File file=new File(EXTERNAL_FILE_PATH+fileName);
		
		if(file.exists()) {
			
			//get the mimetype
			
			String mimeType= URLConnection.guessContentTypeFromName(file.getName());
			if(mimeType == null) {
				mimeType="application/octet-stream";
				
				
			}
			
			response.setContentType(mimeType);
			
			response.setHeader("contenet-Disposition", String.format("inline; filename=\""+ file.getName()+ "\""));
			
			response.setContentLength( (int) file.length());
			
			InputStream inputstream=new BufferedInputStream(new FileInputStream(file));
			
			FileCopyUtils.copy(inputstream, response.getOutputStream());
			
			
		}
		
	}
	
}
